package com.foldercam.app

import android.Manifest
import android.app.AlertDialog
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.Image
import android.media.ImageReader
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.util.Size
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    // ---------- views ----------
    private lateinit var textureView: TextureView
    private lateinit var shutterBtn: Button
    private lateinit var flipBtn: ImageButton
    private lateinit var thumbBtn: ImageButton
    private lateinit var folderBtn: Button
    private lateinit var flashOverlay: android.view.View
    private lateinit var zoomRow: LinearLayout
    private lateinit var zoomLabel: TextView

    // ---------- camera2 ----------
    private val cameraManager by lazy { getSystemService(CAMERA_SERVICE) as CameraManager }
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    private var previewRequestBuilder: CaptureRequest.Builder? = null
    private var sensorOrientation = 90
    private var facingFront = false
    private var activeArraySize: Rect? = null

    // zoom: real optical/logical ratio when the phone exposes it, otherwise a digital crop fallback
    private var zoomRatioSupported = false
    private var zoomMin = 1f
    private var zoomMax = 1f
    private var currentZoom = 1f

    // background thread for all camera I/O so the UI thread never stutters
    private var bgThread: HandlerThread? = null
    private var bgHandler: Handler? = null

    // person / folder
    private lateinit var prefs: android.content.SharedPreferences
    private var people = mutableListOf<String>()
    private var currentPerson = ""

    private val requestPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) openCameraIfReady()
            else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("foldercam", MODE_PRIVATE)
        people = (prefs.getString("people", "") ?: "").split("|").filter { it.isNotBlank() }.toMutableList()
        currentPerson = prefs.getString("current", "") ?: ""

        textureView = findViewById(R.id.texture)
        shutterBtn = findViewById(R.id.shutter)
        flipBtn = findViewById(R.id.flip)
        thumbBtn = findViewById(R.id.thumb)
        folderBtn = findViewById(R.id.folderBtn)
        flashOverlay = findViewById(R.id.flashOverlay)
        zoomRow = findViewById(R.id.zoomRow)
        zoomLabel = findViewById(R.id.zoomLabel)

        updateFolderLabel()
        shutterBtn.setOnClickListener { takePhoto() }
        flipBtn.setOnClickListener { flipCamera() }
        folderBtn.setOnClickListener { showFolderDialog() }
        thumbBtn.setOnClickListener { openGallery() }

        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                setZoom(currentZoom * detector.scaleFactor)
                return true
            }
        })
        textureView.setOnTouchListener { _, event -> scaleDetector.onTouchEvent(event); true }

        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) = openCameraIfReady()
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }
    }

    override fun onResume() {
        super.onResume()
        startBackgroundThread()
        if (textureView.isAvailable) openCameraIfReady()
    }

    override fun onPause() {
        closeCamera()
        stopBackgroundThread()
        super.onPause()
    }

    private fun startBackgroundThread() {
        bgThread = HandlerThread("CameraBg").also { it.start() }
        bgHandler = Handler(bgThread!!.looper)
    }

    private fun stopBackgroundThread() {
        bgThread?.quitSafely()
        try { bgThread?.join() } catch (e: InterruptedException) { }
        bgThread = null
        bgHandler = null
    }

    // ---------- permission + open ----------
    private fun openCameraIfReady() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermission.launch(Manifest.permission.CAMERA)
            return
        }
        openCamera(preferFront = facingFront)
    }

    private fun pickCameraId(preferFront: Boolean): String? {
        for (id in cameraManager.cameraIdList) {
            val c = cameraManager.getCameraCharacteristics(id)
            val facing = c.get(CameraCharacteristics.LENS_FACING)
            if (preferFront && facing == CameraCharacteristics.LENS_FACING_FRONT) return id
            if (!preferFront && facing == CameraCharacteristics.LENS_FACING_BACK) return id
        }
        return cameraManager.cameraIdList.firstOrNull()
    }

    private fun openCamera(preferFront: Boolean) {
        closeCamera()
        val id = pickCameraId(preferFront) ?: run {
            Toast.makeText(this, "No camera found", Toast.LENGTH_LONG).show(); return
        }
        val chars = cameraManager.getCameraCharacteristics(id)
        facingFront = chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        sensorOrientation = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        activeArraySize = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)

        // ---- zoom: use the phone's real zoom-ratio range (covers ultra-wide / sub-1x) when it reports one ----
        val zoomRange =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) chars.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) else null
        if (zoomRange != null) {
            zoomRatioSupported = true
            zoomMin = zoomRange.lower
            zoomMax = zoomRange.upper
        } else {
            zoomRatioSupported = false
            zoomMin = 1f
            zoomMax = chars.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 4f
        }
        currentZoom = 1f
        buildZoomPresets()

        // ---- resolution: ask the sensor for its actual maximum JPEG size instead of guessing ----
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val maxJpeg = map.getOutputSizes(ImageFormat.JPEG).maxByOrNull { it.width.toLong() * it.height } ?: Size(1920, 1080)
        imageReader?.close()
        imageReader = ImageReader.newInstance(maxJpeg.width, maxJpeg.height, ImageFormat.JPEG, 3).apply {
            setOnImageAvailableListener({ reader -> onJpegReady(reader) }, bgHandler)
        }

        val previewSize = choosePreviewSize(map.getOutputSizes(SurfaceTexture::class.java), maxJpeg)
        textureView.surfaceTexture?.setDefaultBufferSize(previewSize.width, previewSize.height)
        configureTransform(previewSize)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        cameraManager.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(device: CameraDevice) { cameraDevice = device; createSession() }
            override fun onDisconnected(device: CameraDevice) { device.close(); cameraDevice = null }
            override fun onError(device: CameraDevice, error: Int) { device.close(); cameraDevice = null }
        }, bgHandler)
    }

    private fun closeCamera() {
        captureSession?.close(); captureSession = null
        cameraDevice?.close(); cameraDevice = null
        imageReader?.close(); imageReader = null
    }

    /** Preview stays capped around 1080p for a fluid viewfinder no matter how big the sensor is;
     *  the full sensor resolution is only asked for on the still-capture path below. */
    private fun choosePreviewSize(sizes: Array<Size>, jpeg: Size): Size {
        val targetArea = 1920 * 1080
        val aspect = jpeg.width.toFloat() / jpeg.height
        return sizes.filter { it.width.toLong() * it.height <= targetArea * 1.2 }
            .sortedByDescending { it.width.toLong() * it.height }
            .firstOrNull { abs((it.width.toFloat() / it.height) - aspect) < 0.12f }
            ?: sizes.minByOrNull { abs(it.width.toLong() * it.height - targetArea) }
            ?: sizes.first()
    }

    private fun configureTransform(previewSize: Size) {
        // portrait-only app, so the buffer (landscape-oriented sensor coordinates) is swapped against the view
        val viewWidth = textureView.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val viewHeight = textureView.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        val matrix = Matrix()
        val viewRect = RectF(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat())
        val bufferRect = RectF(0f, 0f, previewSize.height.toFloat(), previewSize.width.toFloat())
        bufferRect.offset(viewRect.centerX() - bufferRect.centerX(), viewRect.centerY() - bufferRect.centerY())
        matrix.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL)
        val scale = max(viewHeight.toFloat() / previewSize.height, viewWidth.toFloat() / previewSize.width)
        matrix.postScale(scale, scale, viewRect.centerX(), viewRect.centerY())
        textureView.setTransform(matrix)
    }

    private fun createSession() {
        val texture = textureView.surfaceTexture ?: return
        val previewSurface = Surface(texture)
        val reader = imageReader ?: return
        val device = cameraDevice ?: return
        val builder = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
        builder.addTarget(previewSurface)
        builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        previewRequestBuilder = builder

        device.createCaptureSession(listOf(previewSurface, reader.surface), object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(session: CameraCaptureSession) {
                captureSession = session
                applyZoom(builder)
                try { session.setRepeatingRequest(builder.build(), null, bgHandler) } catch (e: Exception) { }
            }
            override fun onConfigureFailed(session: CameraCaptureSession) {
                Toast.makeText(this@MainActivity, "Camera could not start", Toast.LENGTH_LONG).show()
            }
        }, bgHandler)
    }

    // ---------- zoom ----------
    private fun buildZoomPresets() {
        val candidates = listOf(0.25f, 0.5f, 1f, 2f, 3f, 5f, 8f)
        val shown = candidates.filter { z ->
            z == 1f || (zoomRatioSupported && z >= zoomMin - 0.01f && z <= zoomMax + 0.01f) ||
                (!zoomRatioSupported && z in 1f..zoomMax)
        }
        zoomRow.removeAllViews()
        for (z in shown) {
            val b = Button(this)
            b.text = if (z < 1f) (if (z == 0.25f) "0.25x" else "0.5x") else "${z.toInt()}x"
            b.setPadding(24, 8, 24, 8)
            b.setOnClickListener { setZoom(z) }
            zoomRow.addView(b)
        }
    }

    /** Only 1x and above can be achieved digitally on hardware without a reported zoom-ratio range;
     *  below 1x requires the phone's own logical multi-camera zoom API, applied here when present. */
    private fun applyZoom(builder: CaptureRequest.Builder) {
        if (zoomRatioSupported) {
            builder.set(CaptureRequest.CONTROL_ZOOM_RATIO, currentZoom)
        } else {
            val rect = activeArraySize ?: return
            val cropW = (rect.width() / currentZoom).toInt().coerceAtLeast(1)
            val cropH = (rect.height() / currentZoom).toInt().coerceAtLeast(1)
            val cropX = rect.left + (rect.width() - cropW) / 2
            val cropY = rect.top + (rect.height() - cropH) / 2
            builder.set(CaptureRequest.SCALER_CROP_REGION, Rect(cropX, cropY, cropX + cropW, cropY + cropH))
        }
    }

    private fun setZoom(z: Float) {
        currentZoom = z.coerceIn(zoomMin, zoomMax)
        zoomLabel.text = String.format(Locale.US, "%.2fx", currentZoom)
        val builder = previewRequestBuilder ?: return
        applyZoom(builder)
        try { captureSession?.setRepeatingRequest(builder.build(), null, bgHandler) } catch (e: Exception) { }
    }

    private fun flipCamera() = openCamera(preferFront = !facingFront)

    // ---------- shutter ----------
    private fun takePhoto() {
        val session = captureSession ?: return
        val device = cameraDevice ?: return
        val reader = imageReader ?: return

        // ---- instant feedback: freeze the frame already on screen, right now, no waiting on the sensor ----
        flashOverlay.alpha = 0.7f
        flashOverlay.animate().alpha(0f).setDuration(120).start()
        textureView.bitmap?.let { thumbBtn.setImageBitmap(it) }
        Toast.makeText(this, "Saved" + if (currentPerson.isNotBlank()) " · $currentPerson" else "", Toast.LENGTH_SHORT).show()

        // ---- the real full-sensor-resolution still capture happens in the background ----
        try {
            val captureBuilder = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            captureBuilder.addTarget(reader.surface)
            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            captureBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            applyZoom(captureBuilder)
            captureBuilder.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation())
            session.capture(captureBuilder.build(), object : CameraCaptureSession.CaptureCallback() {}, bgHandler)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not capture photo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun jpegOrientation(): Int {
        // activity is locked to portrait, so device rotation relative to natural orientation is always 0 here
        val sign = if (facingFront) -1 else 1
        return ((sensorOrientation * sign) + 360) % 360
    }

    private fun onJpegReady(reader: ImageReader) {
        val image: Image = reader.acquireLatestImage() ?: return
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        image.close()
        saveJpeg(bytes)
    }

    private fun saveJpeg(bytes: ByteArray) {
        val name = "IMG_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + ".jpg"
        val relPath = "Pictures/pani leka chesa" + if (currentPerson.isNotBlank()) "/$currentPerson" else ""
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, relPath)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
        resolver.openOutputStream(uri)?.use { it.write(bytes) }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        runOnUiThread {
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            thumbBtn.setImageBitmap(bmp) // swap the instant preview for the real, final full-resolution photo
        }
    }

    private fun openGallery() {
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW)
        intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "vnd.android.cursor.dir/image")
        try { startActivity(intent) } catch (e: Exception) { Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show() }
    }

    // ---------- person / folder ----------
    private fun updateFolderLabel() {
        folderBtn.text = if (currentPerson.isBlank()) "Normal" else currentPerson
    }

    private fun showFolderDialog() {
        val items = (listOf("Normal") + people).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Save to")
            .setItems(items) { _, which ->
                currentPerson = if (which == 0) "" else items[which]
                prefs.edit().putString("current", currentPerson).apply()
                updateFolderLabel()
            }
            .setPositiveButton("Add new") { _, _ -> promptNewPerson() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptNewPerson() {
        val input = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("Add person")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotBlank() && !people.contains(name)) {
                    people.add(name)
                    prefs.edit().putString("people", people.joinToString("|")).apply()
                }
                currentPerson = name
                prefs.edit().putString("current", currentPerson).apply()
                updateFolderLabel()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
